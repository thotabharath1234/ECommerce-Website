import React from 'react'
import './Loader.css'

const loader = () => {
  return (
    <div className='loading'>
      <div></div>
    </div>
  )
}

export default loader