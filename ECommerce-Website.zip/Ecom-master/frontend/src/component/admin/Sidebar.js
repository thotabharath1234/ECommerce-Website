import React from 'react';
import './Sidebar.css';
import logo from '../../images/logo.png';
import { Link } from 'react-router-dom';
import { TreeView,TreeItem } from '@material-ui/lab';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import PostAddIcon from '@material-ui/icons/PostAdd';
import AddIcon from '@material-ui/icons/Add';
import ImportExportIcon from '@material-ui/icons/ImportExport';
import ListAltIcon from '@material-ui/icons/ListAlt';
import DashboardIcon from '@material-ui/icons/Dashboard';
import PeopleIcon from '@material-ui/icons/People';
import RateReviewIcon from '@material-ui/icons/RateReview';

const Sidebar = () => {
  return (
    <div className='sidebar'>
      {/* logo */}
     <Link to="/">
      <img src={logo} alt="Ecommerce" />
     </Link>
      
      {/* dashboard */}
     <Link to='/admin/dashboard'>
      <p>
        <DashboardIcon /> Dashboard
      </p>
     </Link>
     
      {/* --Products--- */}
     <Link>
       <TreeView
         defaultCollapseIcon={<ExpandMoreIcon />}
         defaultExpandIcon={<ImportExportIcon />}
       >
          <TreeItem nodeId='1' label="Products">
                  {/* all */}
            <Link to='/admin/products'>
              <TreeItem nodeId='2' label="All" icon={<PostAddIcon />}></TreeItem>
            </Link>
                    {/* create */}
            <Link to='/admin/product'>
              <TreeItem nodeId='3' label="Create" icon={<AddIcon />}></TreeItem>
            </Link>

          </TreeItem>
       </TreeView>
     </Link>

       {/* orders */}
     <Link to='/admin/orders'>
              <p>
                <ListAltIcon />
                Orders
              </p>
       </Link>
       {/* users */}

      <Link to='/admin/users'>
        <p>
          <PeopleIcon /> Users
        </p>
      </Link>

      {/* reviews */}

      <Link to='/admin/reviews'>
        <p>
          <RateReviewIcon /> Reviews
        </p>
      </Link>

    </div>
  )
}

export default Sidebar